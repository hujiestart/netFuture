#!/bin/bash -e

pom_g=com/test/example
pom_a=example
pom_v=1.0.0
pom_r=3rd_part


