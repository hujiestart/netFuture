#!/bin/bash -e
cd "`dirname $0`"
sleep 5s
./deploy.sh &
:
